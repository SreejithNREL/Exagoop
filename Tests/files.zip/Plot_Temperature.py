"""
Plot_Temperature.py — 2D Radial Heat Conduction, Cylinder Dirichlet EB BC

Plots T vs r (radial distance from cylinder centre) comparing
ExaGOOP particles to the exact annular steady-state solution.
"""

import argparse
import glob
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ── Problem parameters ────────────────────────────────────────
CX, CY   = 0.5, 0.5
R_INNER  = 0.15
R_OUTER  = 0.50
T_INNER  = 1.0
T_OUTER  = 0.0
N_POS    = 3
T_IDX    = N_POS + 46   # temperature enum index + 3 pos cols

def T_exact_radial(r, R_inner=R_INNER, R_outer=R_OUTER,
                   T_inner=T_INNER, T_outer=T_OUTER):
    r = np.clip(r, R_inner + 1e-10, R_outer)
    return (T_outer * np.log(r / R_inner) - T_inner * np.log(r / R_outer)) \
           / np.log(R_outer / R_inner)

# ── CLI ───────────────────────────────────────────────────────
parser = argparse.ArgumentParser()
parser.add_argument("--time",      type=float, default=0.06)
parser.add_argument("--fileloc",   type=str,   default="Solution/ascii_files")
parser.add_argument("--outputpic", type=str,   default="Temperature_Cylinder.png")
args = parser.parse_args()

time_str = f"matpnt_t{args.time:.6f}"
matches  = glob.glob(f"{args.fileloc}/{time_str}") or \
           glob.glob(f"{args.fileloc}/*/{time_str}")

if not matches:
    print(f"No file found: {time_str}")
    raise SystemExit(1)

data  = np.loadtxt(matches[0], skiprows=5)
x     = data[:, 0]
y     = data[:, 1]
T_num = data[:, T_IDX]

r = np.sqrt((x - CX)**2 + (y - CY)**2)

# Exact
r_plot = np.linspace(R_INNER, R_OUTER, 200)
T_plot = T_exact_radial(r_plot)

# Mask: fluid region only
mask = (r > R_INNER) & (r < R_OUTER + 0.05)
r_c, T_c = r[mask], T_num[mask]

T_ex_at_particles = T_exact_radial(r_c)
rms = np.sqrt(np.mean((T_c - T_ex_at_particles)**2))
print(f"RMS error: {rms:.4e}")

# ── Plot ──────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 6))
ax.scatter(r_c, T_c, s=8, c="black", label="ExaGOOP", zorder=3)
ax.plot(r_plot, T_plot, "r--", lw=2,
        label=f"Exact (steady state)")
ax.axvline(R_INNER, color="gray", ls=":", lw=1, label=f"R_inner={R_INNER}")
ax.axvline(R_OUTER, color="blue", ls=":", lw=1, label=f"R_outer={R_OUTER}")
ax.set_xlabel("r  (distance from cylinder centre)")
ax.set_ylabel("Temperature")
ax.set_title(f"2D Cylinder Dirichlet — T vs r at t={args.time:.4f}\n"
             f"RMS={rms:.2e}")
ax.legend()
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(args.outputpic, dpi=150)
print(f"Saved: {args.outputpic}")
