"""
validate.py — 2D Radial Heat Conduction, Cylinder Dirichlet EB BC

Exact steady-state solution (annular 2D):
  T(r) = ln(r/R_outer) / ln(R_inner/R_outer)
  R_inner = 0.15 (cylinder radius)
  R_outer = 0.50 (effective outer radius = half domain width)

Comparison restricted to particles with R_inner < r < R_compare
to avoid corner artefacts from the square outer boundary.
"""

import sys
import os
import glob
import numpy as np

# ── Problem parameters ────────────────────────────────────────
AMREX_SPACEDIM = 2
USE_TEMP       = True

CX, CY   = 0.5, 0.5   # cylinder centre
R_INNER  = 0.15        # EB radius
R_OUTER  = 0.50        # effective outer radius
T_INNER  = 1.0         # EB Dirichlet
T_OUTER  = 0.0         # outer face Dirichlet
R_COMPARE = 0.42       # exclude corners (r > R_COMPARE may be affected by square BC)
T_TIME   = 0.06        # validation time (should be near steady state)
RMS_TOL  = 5e-02       # tolerance

# ── Field index ───────────────────────────────────────────────
# AMReX always writes 3 position columns regardless of AMREX_SPACEDIM
N_POS = 3
CXX_ENUM = {
    "radius": 0, "xvel": 1, "yvel": 2, "zvel": 3,
    "xvel_prime": 4, "yvel_prime": 5, "zvel_prime": 6,
    "strainrate": 7, "strain": 13, "stress": 19,
    "deformation_gradient": 25,
    "volume": 34, "mass": 35, "density": 36, "jacobian": 37,
    "pressure": 38, "vol_init": 39,
    "E": 40, "nu": 41, "Bulk_modulus": 42, "Gama_pressure": 43,
    "Dynamic_viscosity": 44, "yacceleration": 45,
    "temperature": 46, "specific_heat": 47,
    "thermal_conductivity": 48,
    "heat_flux": 49, "heat_source": 52,
}
T_IDX = N_POS + CXX_ENUM["temperature"]   # = 49

# ── Exact solution ────────────────────────────────────────────
def T_exact_radial(x, y, R_inner=R_INNER, R_outer=R_OUTER,
                   T_inner=T_INNER, T_outer=T_OUTER):
    """Steady-state 2D radial conduction between two cylinders."""
    r = np.sqrt((x - CX)**2 + (y - CY)**2)
    r = np.clip(r, R_inner + 1e-10, R_outer)
    return (T_outer * np.log(r / R_inner) - T_inner * np.log(r / R_outer)) \
           / np.log(R_outer / R_inner)

# ── Find output file ──────────────────────────────────────────
time_str = f"matpnt_t{T_TIME:.6f}"
search_patterns = [
    f"Solution/ascii_files/*/{time_str}",
    f"Solution/ascii_files/{time_str}",
    f"*/{time_str}",
    f"../**/{time_str}",
]
matches = []
for pat in search_patterns:
    matches = glob.glob(pat, recursive=True)
    if matches:
        break

if not matches:
    print(f"FAIL: no {time_str} found")
    sys.exit(1)

fpath = matches[0]
print(f"Found output file: {fpath}")

# ── Load data ─────────────────────────────────────────────────
data  = np.loadtxt(fpath, skiprows=5)
x     = data[:, 0]
y     = data[:, 1]
T_num = data[:, T_IDX]

# ── Filter: fluid region only, away from square-boundary corners
r = np.sqrt((x - CX)**2 + (y - CY)**2)
mask = (r > R_INNER + 0.02) & (r < R_COMPARE)
if mask.sum() == 0:
    print("FAIL: no particles in comparison region")
    sys.exit(1)

x_c, y_c, T_c = x[mask], y[mask], T_num[mask]

# ── Check for NaN ─────────────────────────────────────────────
if np.any(np.isnan(T_c)):
    n_nan = np.sum(np.isnan(T_c))
    print(f"FAIL: {n_nan} NaN values in ExaGOOP temperature")
    sys.exit(1)

# ── Compute RMS ───────────────────────────────────────────────
T_ex  = T_exact_radial(x_c, y_c)
rms   = np.sqrt(np.mean((T_c - T_ex)**2))

print(f"Particles in comparison region: {mask.sum()}")
print(f"T_num range: [{T_c.min():.4f}, {T_c.max():.4f}]")
print(f"T_ex  range: [{T_ex.min():.4f}, {T_ex.max():.4f}]")
print(f"RMS error vs exact: {rms:.4e}  (tolerance: {RMS_TOL:.0e})")

if rms < RMS_TOL:
    print("PASS")
    sys.exit(0)
else:
    print("FAIL")
    sys.exit(1)
