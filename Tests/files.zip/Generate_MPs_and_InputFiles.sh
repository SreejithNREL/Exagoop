#!/usr/bin/env bash
# Generate_MPs_and_InputFiles.sh
# Generates particle file and input file for 2D Cylinder Dirichlet T test.
# Usage: bash Generate_MPs_and_InputFiles.sh [config.json]

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="${1:-${SCRIPT_DIR}/PreProcess/config.json}"
OUTDIR="${SCRIPT_DIR}/Solution"
mkdir -p "${OUTDIR}/ascii_files"

python3 - <<PYEOF
import json, math, os

with open("${CONFIG}") as f:
    cfg = json.load(f)

dom  = cfg["domain"]
mesh = cfg["mesh"]
p    = cfg["particles"]
eb   = cfg["eb"]

xlo, xhi = dom["xlo"], dom["xhi"]
ylo, yhi = dom["ylo"], dom["yhi"]
nx,  ny  = mesh["nx"], mesh["ny"]
dx  = (xhi - xlo) / nx
dy  = (yhi - ylo) / ny

ppc_x, ppc_y = p["ppc"][0], p["ppc"][1]
cx   = eb["center"][0]
cy   = eb["center"][1]
R    = eb["radius"]

rho      = p["rho"]
E        = p["E"]
nu       = p["nu"]
spheat   = p["spheat"]
thermcond= p["thermcond"]
T_init   = p["T_init"]

# Bulk modulus from E, nu
K = E / (3*(1-2*nu))
G = E / (2*(1+nu))

particles = []
for i in range(nx):
    for j in range(ny):
        for pi in range(ppc_x):
            for pj in range(ppc_y):
                xp = xlo + (i + (pi + 0.5)/ppc_x) * dx
                yp = ylo + (j + (pj + 0.5)/ppc_y) * dy
                r  = math.sqrt((xp-cx)**2 + (yp-cy)**2)
                if r <= R:
                    continue  # inside EB, skip
                vol  = dx*dy / (ppc_x*ppc_y)
                mass = rho * vol
                particles.append((xp, yp, vol, mass))

# Write particle file
n = len(particles)
outfile = "${OUTDIR}/mpm_particles.dat"
with open(outfile, "w") as f:
    f.write(f"{n}\n")
    for xp, yp, vol, mass in particles:
        # Format: x y vol mass rho E nu K G spheat thermcond T_init
        f.write(f"{xp:.8f} {yp:.8f} {vol:.8f} {mass:.8f} "
                f"{rho} {E} {nu} {K:.6f} {G:.6f} "
                f"{spheat} {thermcond} {T_init}\n")

print(f"Wrote {n} particles to {outfile}")
PYEOF

echo "Particle file generated."
echo "Input file: ${SCRIPT_DIR}/Inputs_2DCylinderDirichletT.inp"
echo ""
echo "To run:"
echo "  cd ${SCRIPT_DIR}"
echo "  mpirun -np 4 ../../Build_Gnumake/ExaGOOP2d.gnu.MPI.ex Inputs_2DCylinderDirichletT.inp"
echo ""
echo "To plot:"
echo "  python3 PostProcess/Plot_Temperature.py --time 0.06 \\"
echo "          --fileloc Solution/ascii_files/2D_Cylinder_DirichletT \\"
echo "          --outputpic Temperature_Cylinder.png"
